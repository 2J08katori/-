function lesson01(){
    alert('私は国際理工学園を愛しています！');
}

function lesson02(){
    document.getElementById('mojimoji').innerHTML = 'うおおおおおおおおおおおおおお'
}